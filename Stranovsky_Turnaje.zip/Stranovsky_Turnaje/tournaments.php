<?php
include_once("classes/DB.php");

use classes\DB;

$db = new DB("localhost", "root", "", "tournaments", 3306);
$tourItems = $db->getTournaments();

function button1($tid){
    $db = new DB("localhost", "root", "", "tournaments", 3306);
    if($db->checkAttendance($user['ID_U'],$tid)){
        $db->createAttendance($user['ID_U'], $tid,NULL);
    }else{
        echo "You have already entered this tournament";
    }
}
?>
<!-- Middle Column -->
<nav class="w3-col m7">
    <div>
    <?php 
        $num = 0;
        foreach($tourItems as $keys => $tourItem){
        if($tourItem['end']>date('Y-m-d')){
            ?>
            <div class="w3-container w3-card w3-white w3-round w3-margin"><br>
                <img src="/images/game<?php echo $tourItem['ID_Game']?>.png" alt="Cover" class="w3-left w3-circle w3-margin-right" style="width:60px">
                <h4><?php echo $tourItem['T_name']?></h4><br>
                <hr class="w3-clear">
                <p><?php echo $tourItem["description"]?></p>
                    <div class="w3-row-padding" style="margin:0 -16px">
                        <div class="w3-half">
                            <p class="w3-margin-bottom">Start: <?php echo $tourItem['start']?>        End: <?php echo $tourItem['end']?></p>
                        </div>
                        <div class="w3-half">
                            <p class="w3-margin-bottom w3-right"><?php echo $tourItem['G_name']?></p>
                        </div>
                    </div>
                    <!--$user['ID_U']-->
                <?php
                    if(array_key_exists('join'.$num,$_POST)){
                        button1($tourItem['ID_T']);
                    }
                ?>
                <form method="post">
                    <input type="submit" class="w3-button w3-theme-d1 w3-margin-bottom button" name=<?php echo "join".$num; $num = $num+1;?> value ="Join"> </input> 
                </form>
                <!--button type="button" class="w3-button w3-theme-d2 w3-margin-bottom"><i class="fa fa-comment"></i>  Comment</button--> 
            </div>
        <?php
        }
    }
    ?>
    </div>
    <?php 
    ?>
</nav>