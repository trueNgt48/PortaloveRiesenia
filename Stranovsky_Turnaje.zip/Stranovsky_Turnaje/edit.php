<?php
    include_once("classes/DB.php");
    use classes\DB;

    $db = new DB("localhost", "root", "", "tournaments", 3306);
    $db->updateTournament($_POST["tourID"],$_POST["name"],$_POST["start"],$_POST["end"],$_POST["desc"],$_POST["street"],$_POST["game"]);
    header("Location: showTour.php?tour=".$_POST["tourID"]."&us=".$_POST["userID"])
?>