<?php

namespace classes;

class DB
{
    /**
     * @var string
     */
    private $host = "localhost";
    /**
     * @var string
     */
    private $username = "root";
    /**
     * @var string
     */
    private $password = "";
    /**
     * @var string
     */
    private $dbName = "";
    /**
     * @var int
     */
    private $port;
    /**
     * @var \PDO
     */
    private $connection;

    /**
     * DB constructor.
     * @param $host
     * @param $username
     * @param $password
     * @param $dbName
     * @param int $port
     */
    public function __construct($host, $username, $password, $dbName, $port = 3306)
    {
        $this->host = $host;
        $this->username = $username;
        $this->password = $password;
        $this->dbName = $dbName;
        $this->port = $port;

        try {
            $connection = new \PDO("mysql:host=".$this->host.";dbname=".$this->dbName.";port=".$this->port, $this->username, $this->password);
            $connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            $this->connection = $connection;
        } catch (\PDOException $exception) {
            echo "Error while database connect " . $exception->getMessage();
        }
    }

    /**
     * @return \PDO
     */
    public function getConnection()
    {
        return $this->connection;
    }

    /**
     * @param $connectio
     */
    public function setConnection($connectio)
    {
        if($connectio instanceof \PDO) {
            $this->connection = $connectio;
        }
    }

    /**
     * @return array
     */
    public function getTournaments()
    {
        $sql = "SELECT tournaments.*, gametypes.*, street.*, town.*, country.* FROM tournaments INNER JOIN gametypes ON gametypes.ID_G = tournaments.ID_Game INNER JOIN street ON street.ID_S = tournaments.ID_Street INNER JOIN town ON town.ID_TW = street.ID_Town INNER JOIN country ON country.ID_C = town.ID_Country ORDER BY ID_T";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * @return array
     */
    public function getTournament($tourID)
    {
        $sql = "SELECT tournaments.*, gametypes.*, street.*, town.*, country.* FROM tournaments INNER JOIN gametypes ON gametypes.ID_G = tournaments.ID_Game INNER JOIN street ON street.ID_S = tournaments.ID_Street INNER JOIN town ON town.ID_TW = street.ID_Town INNER JOIN country ON country.ID_C = town.ID_Country WHERE tournaments.ID_T = ".$tourID;
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetch();
    }

    /**
     * @return array
     */
    public function getUsers()
    {
        $sql = "SELECT user.*, usertype.*, street.*, town.*, country.* FROM user INNER JOIN usertype ON usertype.ID_UT = user.ID_Type INNER JOIN street ON street.ID_S = user.ID_Street INNER JOIN town ON town.ID_TW = street.ID_Town INNER JOIN country ON country.ID_C = town.ID_Country ORDER BY ID_U";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * @return array
     */
    public function getUser($userID)
    {
        $sql = "SELECT user.*, usertype.*, street.*, town.*, country.* FROM user INNER JOIN usertype ON usertype.ID_UT = user.ID_Type INNER JOIN street ON street.ID_S = user.ID_Street INNER JOIN town ON town.ID_TW = street.ID_Town INNER JOIN country ON country.ID_C = town.ID_Country WHERE ID_U = ".$userID;
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetch();
    }
    
    /**
     * @return array
     */
    public function getCountries()
    {
        $sql = "SELECT * FROM country ORDER BY ID_Country";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    
    /**
     * @return array
     */
    public function getTowns()
    {
        $sql = "SELECT * FROM town ORDER BY ID_Town";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    
    /**
     * @return array
     */
    public function getStreets()
    {
        $sql = "SELECT * FROM street ORDER BY ID_S";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    
    /**
     * @return array
     */
    public function getUserTypes()
    {
        $sql = "SELECT * FROM usertype ORDER BY ID_UT";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }
    
    /**
     * @return array
     */
    public function getGameTypes()
    {
        $sql = "SELECT * FROM gametypes ORDER BY ID_G";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }    

    /**
     * @return array
     */
    public function getAttendanceU($userid)
    {
        $sql = "SELECT user.*, tournaments.*, attendance.* FROM user INNER JOIN attendance ON attendance.ID_User = user.ID_U INNER JOIN tournaments ON tournaments.ID_T = attendance.ID_Tournament WHERE user.ID_U = ". $userid ." ORDER BY attendance.ID_A";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * @return array
     */
    public function getAttendanceT($tourid)
    {
        $sql = "SELECT user.*, tournaments.*, attendance.* FROM user INNER JOIN attendance ON attendance.ID_User = user.ID_U INNER JOIN tournaments ON tournaments.ID_T = attendance.ID_Tournament WHERE tournaments.ID_T = ". $tourid ." ORDER BY attendance.ID_A";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * @return array
     */
    public function getOrganizer($userid)
    {
        $sql = "SELECT user.*, tournaments.*, organizer.* FROM user INNER JOIN organizer ON organizer.ID_User = user.ID_U INNER JOIN tournaments ON tournaments.ID_T = organizer.ID_Tournament WHERE user.ID_U = ". $userid ." ORDER BY organizer.ID_O";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * @return array
     */
    public function checkOrganizer($userID,$tourID)
    {
        $sql = "SELECT user.*, tournaments.*, organizer.* FROM user INNER JOIN organizer ON organizer.ID_User = user.ID_U INNER JOIN tournaments ON tournaments.ID_T = organizer.ID_Tournament WHERE user.ID_U = ". $userID ." AND tournaments.ID_T = ".$tourID;
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return !empty($stmt->fetchAll(\PDO::FETCH_ASSOC));
    }

    public function updateTournament($tourID, $name, $start, $end, $desc, $streetID, $gameID)
    {
        $sql = "UPDATE tournaments SET T_name = '".$name."', start = '". $start ."', end = '" .$end. "', description = '" .$desc. "', ID_Game = '".$gameID."', ID_Street = '".$streetID."' WHERE tournaments.ID_T =".$tourID;
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
    }

    public function deleteAttendance($attID)
    {
        $sql = "DELETE FROM attendance WHERE ID_A =".$attID;
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
    }

    public function createAttendance($userID, $tourID, $poss)
    {
        $sql = "INSERT INTO attendance (ID_A, ID_User, ID_Tournament, position) VALUES (NULL, '".$userID."', '".$tourID."', '".$poss."')";
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
    }

    public function checkAttendance($userID, $tourID)
    {
        $sql = "SELECT * FROM attendance WHERE ID_User = ".$userID." AND ID_Tournament = ".$tourID;
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return empty($stmt->fetchALL(\PDO::FETCH_ASSOC));
    }

    public function checkAttendanceE($attID)
    {
        $sql = "SELECT * FROM attendance WHERE ID_A = ".$attID;
        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        return !empty($stmt->fetchALL(\PDO::FETCH_ASSOC));
    }
}