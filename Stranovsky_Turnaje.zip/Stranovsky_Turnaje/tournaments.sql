-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2020 at 01:40 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tournaments`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `ID_A` int(11) NOT NULL,
  `ID_User` int(11) NOT NULL,
  `ID_Tournament` int(11) NOT NULL,
  `position` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`ID_A`, `ID_User`, `ID_Tournament`, `position`) VALUES
(1, 1, 1, 1),
(3, 1, 4, 1),
(5, 1, 3, 2),
(7, 1, 2, 0),
(13, 2, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `ID_C` int(11) NOT NULL,
  `C_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`ID_C`, `C_name`) VALUES
(1, 'Slovensko'),
(2, 'Cesko');

-- --------------------------------------------------------

--
-- Table structure for table `gametypes`
--

CREATE TABLE `gametypes` (
  `ID_G` int(11) NOT NULL,
  `G_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gametypes`
--

INSERT INTO `gametypes` (`ID_G`, `G_name`) VALUES
(1, 'YuGiOh'),
(2, 'MTG'),
(3, 'Pokemon');

-- --------------------------------------------------------

--
-- Table structure for table `organizer`
--

CREATE TABLE `organizer` (
  `ID_O` int(11) NOT NULL,
  `ID_User` int(11) NOT NULL,
  `ID_Tournament` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organizer`
--

INSERT INTO `organizer` (`ID_O`, `ID_User`, `ID_Tournament`) VALUES
(1, 3, 1),
(2, 3, 2),
(3, 3, 3),
(4, 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `street`
--

CREATE TABLE `street` (
  `ID_S` int(11) NOT NULL,
  `S_name` varchar(45) NOT NULL,
  `ID_Town` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `street`
--

INSERT INTO `street` (`ID_S`, `S_name`, `ID_Town`) VALUES
(1, 'Karlickova', 1),
(2, 'Slivova', 2),
(3, 'Palikova', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tournaments`
--

CREATE TABLE `tournaments` (
  `ID_T` int(11) NOT NULL,
  `T_name` varchar(45) NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  `description` text DEFAULT NULL,
  `ID_Game` int(11) NOT NULL,
  `ID_Street` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tournaments`
--

INSERT INTO `tournaments` (`ID_T`, `T_name`, `start`, `end`, `description`, `ID_Game`, `ID_Street`) VALUES
(1, 'YuGiOh3', '2020-12-03', '2020-12-05', 'First YuGiOh tournament. Winner gets Exodia', 1, 1),
(2, 'YuGiOh2', '2020-12-07', '2020-12-11', 'Second YuGiOh tournament. This one is used to test search function', 1, 3),
(3, 'Pokemon1', '2020-12-02', '2020-12-09', 'Pokemon tournament. This could honestly be lorem ipsum', 3, 2),
(4, 'MTG1', '2020-11-24', '2020-11-26', 'Description because why nots', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `town`
--

CREATE TABLE `town` (
  `ID_TW` int(11) NOT NULL,
  `TW_name` varchar(45) NOT NULL,
  `ID_Country` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `town`
--

INSERT INTO `town` (`ID_TW`, `TW_name`, `ID_Country`) VALUES
(1, 'Nitra', 1),
(2, 'Kosice', 1),
(3, 'Praha', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `ID_U` int(11) NOT NULL,
  `U_name` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `email` varchar(45) NOT NULL,
  `ID_Type` int(11) NOT NULL,
  `ID_Street` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`ID_U`, `U_name`, `password`, `email`, `ID_Type`, `ID_Street`) VALUES
(1, 'a', '1234', 'az@gmail.com', 1, 1),
(2, 'b', 'pass', 'bb@gmai.com', 1, 3),
(3, 'c', 'pa34', 'c@gmail.com', 2, 2),
(4, 'admin', 'admin', 'admin@gmail.com', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `usertype`
--

CREATE TABLE `usertype` (
  `ID_UT` int(11) NOT NULL,
  `UT_name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usertype`
--

INSERT INTO `usertype` (`ID_UT`, `UT_name`) VALUES
(1, 'user'),
(2, 'organizer'),
(3, 'admin'),
(4, 'banned');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`ID_A`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`ID_C`);

--
-- Indexes for table `gametypes`
--
ALTER TABLE `gametypes`
  ADD PRIMARY KEY (`ID_G`);

--
-- Indexes for table `organizer`
--
ALTER TABLE `organizer`
  ADD PRIMARY KEY (`ID_O`);

--
-- Indexes for table `street`
--
ALTER TABLE `street`
  ADD PRIMARY KEY (`ID_S`);

--
-- Indexes for table `tournaments`
--
ALTER TABLE `tournaments`
  ADD PRIMARY KEY (`ID_T`);

--
-- Indexes for table `town`
--
ALTER TABLE `town`
  ADD PRIMARY KEY (`ID_TW`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID_U`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `name` (`U_name`);

--
-- Indexes for table `usertype`
--
ALTER TABLE `usertype`
  ADD PRIMARY KEY (`ID_UT`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `ID_A` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `ID_C` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gametypes`
--
ALTER TABLE `gametypes`
  MODIFY `ID_G` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `organizer`
--
ALTER TABLE `organizer`
  MODIFY `ID_O` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `street`
--
ALTER TABLE `street`
  MODIFY `ID_S` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tournaments`
--
ALTER TABLE `tournaments`
  MODIFY `ID_T` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `town`
--
ALTER TABLE `town`
  MODIFY `ID_TW` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `ID_U` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `usertype`
--
ALTER TABLE `usertype`
  MODIFY `ID_UT` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
